# Les Royaumes de l’Éclipse

Jeu d’action fantastique pour navigateur sur PC et téléphone : aventure solo, coopération de 2 à 4 joueurs et battle en duel ou en équipes.

## Version 0.1 jouable

Ouvrir `index.html` dans un navigateur sur PC, ou héberger ce fichier en HTTPS pour jouer sur téléphone. Le jeu n’utilise aucune dépendance externe.

- Deux personnages : Voltigeur et Dernier Rempart.
- Déplacement, attaque, esquive et pouvoir ; clavier/souris ou tactile avec visée automatique.
- Épreuve solo : vaincre 12 gardiens, survivre 25 secondes aux reflets puis rejoindre la porte au nord.
- Pause, choix du personnage, victoire et défaite.

Sur PC : ZQSD / WASD / flèches ; souris pour viser ; clic pour attaquer ; Espace pour esquiver ; E pour le pouvoir ; Échap pour la pause. Sur téléphone, utiliser les boutons tactiles ; paysage conseillé.

Cette version utilise des graphismes procéduraux simples. Elle ne contient pas encore de comptes, sauvegarde, coopération, battle, audio ni les autres personnages et niveaux. L’objectif est de valider les commandes et les combats.

## Vérifications

Vérifiée dans Chromium avec Playwright : déplacement, attaque à distance, esquive, pouvoirs, pause/reprise, transitions des épreuves, victoire, défaite et interface mobile simulée. Les transitions ont été accélérées pour les tests. Le confort, l’équilibrage et la compatibilité iPhone/Android restent à vérifier sur appareils réels.

## Documents

Voir [le document de conception](docs/CONCEPTION.md) et [la préparation GitHub](docs/GITHUB.md). `archive/relay-raid.html` conserve le prototype initial sans modification.
