# La nef des serments — prototype 3D 0.3

Une séquence solo de trois salles du premier grand niveau, la Cathédrale vivante. Ce ne sont pas encore les trois grands niveaux complets. Modèles et décors procéduraux simples ; Three.js 0.160.1 intégré au HTML, sans chargement externe au lancement.

## Nouveautés

- Accélération, freinage et rotation progressifs, caméra lissée et animation de marche dépendante de la vitesse. Simulation fixe à 60 pas/seconde, indépendante du rafraîchissement de l’écran. La fluidité réelle reste dépendante du téléphone.
- Collisions du déplacement et de l’esquive avec les murs et obstacles ; les projectiles s’arrêtent sur les obstacles.
- Salle I : deux passages et un pacte exclusif. Vigueur donne +40 PV maximum ; Élan réduit la recharge de l’esquive. Deux ennemis facultatifs, dont un tireur qui annonce ses tirs.
- Salle II : lignes de feu avec avertissement, période active et passages sûrs alternés. Atteindre l’éclat ouvre la sortie et rend 30 PV. Deux tireurs fixes, sans apparitions infinies.
- Salle III : boss à deux phases, frappes ciblées, fissures alignées et salves circulaires. Armure résistante, puis fenêtre de vulnérabilité dorée après ses attaques. Un bouclier déclenché à proximité pendant sa préparation peut l’interrompre.
- Recul de tir, flash au canon, impacts, son synthétisé désactivable et avertissements de dégâts.

## Publier depuis le téléphone

Pour tester sans remplacer l’ancienne version, télécharger `cathedrale-v03.html` et l’ajouter dans le dossier `docs` du dépôt GitHub. Garder GitHub Pages sur `main` → `/docs`. Après déploiement, ouvrir :

https://mativ117.github.io/royaumes-eclipse/cathedrale-v03.html

L’accueil doit afficher **La nef des serments** et **Version 0.3**. Le fichier `index.html` contient exactement le même jeu ; il peut remplacer `docs/index.html` lorsqu’on souhaite changer l’accueil par défaut. Aucune mise à jour distante n’a été effectuée par l’assistant.

## Commandes

PC : ZQSD/WASD/flèches ; souris pour viser ; clic pour tirer ; Espace pour esquiver ; E pour le bouclier ; Échap pour la pause.

Téléphone : joystick, tir à visée automatique, esquive et bouclier. Paysage conseillé ; qualité légère disponible au menu. Le son est activé au démarrage après une interaction utilisateur, si le navigateur l’autorise, et peut être coupé avec le bouton Son.

Bouclier : trois secondes de protection et onde de choc à courte portée. Les pactes sont obtenus en s’approchant d’une offrande. Les portes ouvertes se franchissent en marchant vers elles.

## Sources et vérifications

`src/game.js` contient le jeu ; `src/template.html` contient l’interface et le moteur intégré. `python build.py` régénère `index.html`. Copier ensuite ce fichier vers `cathedrale-v03.html` pour la distribution nommée.

`tests/smoke.py` utilise Python Playwright et Chromium (`/usr/bin/chromium`). Vérifications : accélération/freinage, collisions et esquive, deux pactes exclusifs, rencontres limitées, transitions entre salles, pièges et passages sûrs, armure du boss, vulnérabilité, interruption, deuxième phase, victoire obtenue par projectiles, pause, défaite et vrai multitouch simulé (déplacement + tir). Certaines situations sont accélérées par le test. Aucun test sur Safari/iPhone physique ni validation de performances réelle.

## Limites

Un personnage ; trois variations d’une même architecture. Pas encore de comptes, sauvegardes, coop, battle, modèles détaillés, ombres dynamiques ou reflets d’eau. Une défaite relance l’expédition depuis le début. Ce prototype valide les mécaniques, sans constituer un niveau final ni un équilibrage définitif.

Three.js est sous licence MIT (incluse dans le HTML et THIRD_PARTY_LICENSE.txt). Cette licence du moteur ne définit pas celle des créations du jeu. Les prototypes 2D et 3D précédents sont conservés dans `archive` à la racine du projet.
