"""Build the single-file release from the template (with vendored Three.js) and game source."""
from pathlib import Path
root = Path(__file__).resolve().parent
template = (root / 'src/template.html').read_text()
game = (root / 'src/game.js').read_text()
(root / 'index.html').write_text(template.replace('<!-- GAME_SCRIPT -->', '<script>' + game + '</script>'))
print('Built index.html')
