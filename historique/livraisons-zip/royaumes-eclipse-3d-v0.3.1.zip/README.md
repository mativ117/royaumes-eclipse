# La nef des serments — prototype 3D 0.3.1

Une séquence solo de trois salles du premier grand niveau, la Cathédrale vivante. Ce ne sont pas encore les trois grands niveaux complets. Modèles et décors procéduraux simples ; Three.js 0.160.1 intégré au HTML, sans chargement externe au lancement.

## Correctif 0.3.1

La version précédente déclenchait une pause sur chaque événement `window.blur`. Ce comportement est reproduit par le test : un simple changement de focus suffisait à interrompre la partie. La nouvelle version ne met plus en pause sur ce signal. Les entrées clavier/souris sont relâchées ; un geste tactile déjà actif reste utilisable. La pause automatique intervient lorsque la page est masquée, et la pause manuelle reste disponible. Une interruption WebGL est signalée séparément.

Le focus des boutons de menu est retiré au retour au jeu pour éviter qu’Espace déclenche un bouton au lieu d’une esquive. Les contrôles tactiles bloquent les gestes de défilement/sélection pendant le jeu ; leur annulation relâche les entrées. Ajout d’une reprise à l’entrée de la salle après défaite.

`tests/input_regression.py` vérifie en portrait et paysage les gestes multitouch déplacement/tir/esquive pendant une perte de focus, leur relâchement, la rotation de l’écran, la pause manuelle et masquée, les commandes clavier et la reprise avec pacte. Les événements de focus et de visibilité sont injectés pour tester les cas de régression ; les gestes tactiles passent par le protocole d’entrée du navigateur. Chromium passe ces vérifications sans erreur JavaScript. Safari/iPhone réel reste à confirmer ; WebKit n’est pas installé dans cet environnement.

Pour remplacer la version précédente, importer **le nouveau fichier `cathedrale-v03.html` dans `docs`**, sous le même nom. Ne pas modifier la source de GitHub Pages. Puis ouvrir `https://mativ117.github.io/royaumes-eclipse/cathedrale-v03.html?v=031`. Le suffixe aide à demander une nouvelle copie après le déploiement ; l’accueil doit afficher Version 0.3.1.

## Nouveautés du chapitre

- Accélération, freinage et rotation progressifs, caméra lissée et animation de marche dépendante de la vitesse. Simulation fixe à 60 pas/seconde, indépendante du rafraîchissement de l’écran. La fluidité réelle reste dépendante du téléphone.
- Collisions du déplacement et de l’esquive avec les murs et obstacles ; les projectiles s’arrêtent sur les obstacles.
- Salle I : deux passages et un pacte exclusif. Vigueur donne +40 PV maximum ; Élan réduit la recharge de l’esquive. Deux ennemis facultatifs, dont un tireur qui annonce ses tirs.
- Salle II : lignes de feu avec avertissement, période active et passages sûrs alternés. Atteindre l’éclat ouvre la sortie et rend 30 PV. Deux tireurs fixes, sans apparitions infinies.
- Salle III : boss à deux phases, frappes ciblées, fissures alignées et salves circulaires. Armure résistante, puis fenêtre de vulnérabilité dorée après ses attaques. Un bouclier déclenché à proximité pendant sa préparation peut l’interrompre.
- Recul de tir, flash au canon, impacts, son synthétisé désactivable et avertissements de dégâts.

## Publier depuis le téléphone

Pour tester sans remplacer l’ancienne version, télécharger `cathedrale-v03.html` et l’ajouter dans le dossier `docs` du dépôt GitHub. Garder GitHub Pages sur `main` → `/docs`. Après déploiement, ouvrir :

https://mativ117.github.io/royaumes-eclipse/cathedrale-v03.html

L’accueil doit afficher **La nef des serments** et **Version 0.3.1**. Le fichier `index.html` contient exactement le même jeu ; il peut remplacer `docs/index.html` lorsqu’on souhaite changer l’accueil par défaut. Aucune mise à jour distante n’a été effectuée par l’assistant.

## Commandes

PC : ZQSD/WASD/flèches ; souris pour viser ; clic pour tirer ; Espace pour esquiver ; E pour le bouclier ; Échap pour la pause.

Téléphone : joystick, tir à visée automatique, esquive et bouclier. Paysage conseillé ; qualité légère disponible au menu. Le son est activé au démarrage après une interaction utilisateur, si le navigateur l’autorise, et peut être coupé avec le bouton Son.

Bouclier : trois secondes de protection et onde de choc à courte portée. Les pactes sont obtenus en s’approchant d’une offrande. Les portes ouvertes se franchissent en marchant vers elles.

## Sources et vérifications

`src/game.js` contient le jeu ; `src/template.html` contient l’interface et le moteur intégré. `python build.py` régénère `index.html`. Le script régénère aussi `cathedrale-v03.html` pour la publication nommée.

`tests/smoke.py` utilise Python Playwright et Chromium (`/usr/bin/chromium`). Vérifications : accélération/freinage, collisions et esquive, deux pactes exclusifs, rencontres limitées, transitions entre salles, pièges et passages sûrs, armure du boss, vulnérabilité, interruption, deuxième phase, victoire obtenue par projectiles, pause, défaite et vrai multitouch simulé (déplacement + tir). Certaines situations sont accélérées par le test. Aucun test sur Safari/iPhone physique ni validation de performances réelle.

## Limites

Un personnage ; trois variations d’une même architecture. Pas encore de comptes, sauvegardes, coop, battle, modèles détaillés, ombres dynamiques ou reflets d’eau. Une défaite permet de reprendre au début de la salle en cours, avec le pacte conservé et les PV restaurés. Le combat et les pièges de cette salle sont réinitialisés. Ce point de reprise reste en mémoire : recharger la page le perd. Ce prototype valide les mécaniques, sans constituer un niveau final ni un équilibrage définitif.

Three.js est sous licence MIT (incluse dans le HTML et THIRD_PARTY_LICENSE.txt). Cette licence du moteur ne définit pas celle des créations du jeu. Les prototypes 2D et 3D précédents sont conservés dans `archive` à la racine du projet.
