# Le seuil de cendres — prototype 3D 0.2

Salle test solo en WebGL avec Three.js 0.160.1 intégré au HTML. Aucun téléchargement de modèle ou de moteur n’est nécessaire au lancement. Les personnages et décors utilisent des formes 3D procédurales, pas encore les modèles définitifs.

## Publication sur le dépôt existant

Télécharger uniquement `index.html` dans ce dossier et remplacer `docs/index.html` sur GitHub. GitHub Pages doit rester réglé sur `main` → `/docs`. Attendre la fin du déploiement puis actualiser le lien habituel. Le prototype 2D reste conservé localement dans `archive/prototype-2d-v0.1.html`.

## Jeu

Vaincre 10 gardiens, puis rejoindre la porte dorée au fond de la salle. Tir doré, esquive violette et bouclier bleu : 3 secondes de protection avec onde de choc. Les cercles rouges annoncent les frappes ennemies. Des soins sont accordés tous les trois ennemis vaincus.

PC : ZQSD/WASD/flèches, souris pour viser, clic pour tirer, Espace pour esquiver, E pour le bouclier et Échap pour la pause. Téléphone : joystick et boutons, visée automatique. Paysage conseillé ; qualité légère disponible au menu.

## Vérification et limites

Tests automatisés Chromium/WebGL logiciel sur PC et mobile simulé : rendu 3D, déplacement, tirs, esquive, protection, pause/reprise, dégâts, victoire, défaite et réglage de qualité. Les états de victoire et défaite sont accélérés par le test. Aucun test de performances sur téléphone physique ou de Safari réel n’a encore été effectué.

Un personnage, une salle et une règle simple pour valider la 3D. Pas encore de comptes, coop, battle, audio, modèles détaillés, ombres dynamiques ou reflets d’eau. Les collisions de déplacement concernent les limites rectangulaires de la salle. Aucune progression n’est sauvegardée.

Three.js est distribué sous licence MIT ; voir THIRD_PARTY_LICENSE.txt. Le choix de cette licence pour le moteur ne définit pas une licence pour les créations du jeu.
