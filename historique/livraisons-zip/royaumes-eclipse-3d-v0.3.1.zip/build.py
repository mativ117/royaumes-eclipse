"""Build the single-file release from the template (with vendored Three.js) and game source."""
from pathlib import Path
root = Path(__file__).resolve().parent
template = (root / 'src/template.html').read_text()
game = (root / 'src/game.js').read_text()
html = template.replace('<!-- GAME_SCRIPT -->', '<script>' + game + '</script>')
for filename in ('index.html', 'cathedrale-v03.html'):
    (root / filename).write_text(html)
print('Built index.html and cathedrale-v03.html')
