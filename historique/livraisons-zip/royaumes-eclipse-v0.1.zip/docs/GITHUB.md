# Création du dépôt GitHub

- **Repository name** : `royaumes-eclipse`
- **Description** : `Jeu d’action fantastique sur PC et mobile : solo, coopération et battle dans les Royaumes de l’Éclipse.`
- **Visibility** : Private pendant le développement recommandé ; Public si le code doit être visible dès maintenant.
- **Add README** : désactivé si vous importez le README de ce dossier.
- **Add .gitignore** : aucun modèle nécessaire à ce stade ; le fichier est fourni.
- **License** : aucune pour le moment, en attendant de choisir les droits accordés sur le code et les créations.

Importer le contenu du dossier `royaumes-eclipse` à la racine du dépôt. Ne pas importer de mots de passe, clés privées, fichiers `.env` ni données de joueurs.

GitHub conserve le code. GitHub Pages pourra héberger le client web statique ; les comptes, sauvegardes en ligne et services réseau nécessiteront des services supplémentaires. Le fichier `index.html` contient maintenant la version 0.1 solo jouable, encore au stade de prototype. Pour cet ajout depuis un téléphone, utiliser Add file → Upload files et importer `index.html` à la racine du dépôt. Le dépôt privé peut nécessiter une offre GitHub adaptée pour GitHub Pages ; ne pas changer sa visibilité sans avoir décidé de rendre le code public.
