# Anciennes versions et originaux

- `originaux/` : fichiers fournis au début de la conversation.
- `relay-raid-original.html` : prototype initial.
- `prototype-2d-v0.1.html` : première salle 2D des Royaumes.
- `prototype-3d-v0.2.html` : première salle 3D.
- `cathedrale-v0.3.html` : trois salles, pactes, pièges et boss.
- `cathedrale-v0.3.1.html` : correctif de pause et reprise après défaite.
- `cathedrale-v0.4.html` : serments, conséquences et secret.
- `cathedrale-v0.5.html` : deuxième héros, combo de lame et bond.
- `cathedrale-v0.6.html` : Sentinelles directionnelles et cloche du Silence.
- `cathedrale-v0.7.html` : architecture, éclairage orange, textures et brume.
- `cathedrale-v0.8.html` : monde relié, routes, refuges, carte et Oracle.
- `cathedrale-v0.9.html` : Carillon des Âmes, épreuves liées, ailes, combat animé, sauvegarde et extraction.
- `cathedrale-v0.9.1.html` : carte nommée, objets distincts, journal et guidage facultatif.
- `cathedrale-v0.10.html` : guidage stabilisé, pieds articulés, silhouettes ennemies et mise en scène des ailes.
- `cathedrale-v0.11.html` : direction picturale, nature et vent, mécanismes modelés, portes animées et affichage épuré.
- `cathedrale-v0.12.html` : héros GLB articulés, parvis reconstruit, bassin, caméra rapprochée et comparaison avant/après.
- `cathedrale-v0.13.html` : collisions des objets, glissement, marche selon déplacement réel et ombres stabilisées.
- `cathedrale-v0.14.html` : esquive décélérée, avancée des frappes, espacement des acteurs et gardiens coordonnés.
- `cathedrale-v0.15.html` : jambes et haut du corps indépendants, appuis au sol, prise à deux mains et animations des armes révisées.
- `depot-avant-reorganisation/` : copies exactes des anciens jeux récupérés sur GitHub.
- `livraisons-zip/` : tous les ZIP de livraison disponibles avant ce paquet complet, avec leurs sources et documents à chaque étape.
- `INVENTAIRE.json` : tailles et empreintes des archives pour contrôler leur intégrité.

Les archives ne sont pas publiées par GitHub Pages lorsque la source est /docs. Elles ne constituent pas un historique Git complet ; elles conservent les fichiers disponibles dans cette session.

- `royaumes-v1.0-rc1.html` : version candidate à trois chapitres, dix héros et un secret, modes locaux ; snapshot autonome avec les onze modèles intégrés.
- `livraisons-zip/royaumes-eclipse-1.0-rc1.zip` : projet de la version 1.0, fichiers jouables et archives HTML/sources. Les anciens ZIP restent dans le dépôt ; ils ne sont pas imbriqués récursivement dans ce paquet.

- `royaumes-v1.1-rc2.html` : passe Ambre et obsidienne, matières, contre-jour, capes et réactions de mouvement, chronique et trois thèmes musicaux ; onze modèles intégrés.
- `livraisons-zip/royaumes-eclipse-1.1-rc2.zip` : sources et jeu de cette passe, captures comparatives et archives HTML précédentes.

- `royaumes-v1.1-rc3.html` et `livraisons-zip/royaumes-eclipse-1.1-rc3.zip` : correctif des messages masqués, cibles proches, occultations et appuis ; contenu antérieur conservé.

- `royaumes-v1.2-rc1.html` et `livraisons-zip/royaumes-eclipse-1.2-rc1.zip` : première production 3D de la Lame après validation du concept, atelier animé, disposition PC et touches solo configurables. Les personnages et créatures restants gardent leurs ressources précédentes.

- `royaumes-v1.3-rc1.html` et `livraisons-zip/royaumes-eclipse-1.3-rc1.zip` : atelier réel intégré au choix du personnage, seconde production de la Lame, transitions révisées et matières photographiques CC0 dans le niveau et l’atelier. Les autres personnages et créatures restent en attente de leur refonte détaillée. Les anciennes archives ne sont pas remplacées.
