RELAY RAID — prototype coop navigateur

1. Publiez index.html via GitHub Pages ou un hébergement de sites statiques HTTPS.
2. Chaque joueur ouvre la même URL.
3. L'hôte clique sur « Créer une partie » et communique le code affiché.
4. Les autres entrent ce code et cliquent « Rejoindre ».
5. ZQSD/WASD : se déplacer ; souris : viser ; clic/espace : tirer ; E : réparer un relais ou réanimer.
   Sur écran tactile : joystick gauche, ACTION droite (tir automatique vers les ennemis proches).

Objectif : réparer 3 relais puis survivre 22 secondes jusqu'à l'extraction.

Dépendance : PeerJS 1.5.5 chargé via CDN et serveur public PeerServer Cloud pour la négociation WebRTC.
Limitations : prototype non testé en réseau réel ; certaines connexions NAT peuvent échouer sans serveur TURN.
L'hôte doit rester connecté. Un code de salon n'est pas une authentification forte.
